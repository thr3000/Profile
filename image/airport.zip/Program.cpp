//Baoying Feng CS302-1003 April 12, 2019

#include <iostream>
#include <vector>
#include <ctime>
#include <string>
#include <stack>
#include <map>
#include <fstream>

using namespace std;

// BinaryHeap class
//
// CONSTRUCTION: with an optional capacity (that defaults to 100)
//
// ******************PUBLIC OPERATIONS*********************
// void insert( x )       --> Insert x
// deleteMin( minItem )   --> Remove (and optionally return) smallest item
// Comparable findMin( )  --> Return smallest item
// bool isEmpty( )        --> Return true if empty; else false
// void makeEmpty( )      --> Remove all items
// ******************ERRORS********************************
// Throws UnderflowException as warranted

class UnderflowException {};

template <typename Comparable>
class BinaryHeap
{
public:
	explicit BinaryHeap(int capacity = 100)
		: array(capacity + 1), currentSize(0)
	{
	}

	explicit BinaryHeap(const vector<Comparable> & items)
		: array(items.size() + 10), currentSize(items.size())
	{
		for (int i = 0; i < items.size(); i++)
			array[i + 1] = items[i];
		buildHeap();
	}

	bool isEmpty() const
	{
		return currentSize == 0;
	}

	/**
	 * Find the smallest item in the priority queue.
	 * Return the smallest item, or throw Underflow if empty.
	 */
	const Comparable & findMin() const
	{
		if (isEmpty())
			throw UnderflowException();
		return array[1];
	}
	/**
	 * Insert item x, allowing duplicates.
	 */
	void insert(const Comparable & x)
	{
		if (currentSize == array.size() - 1)
			array.resize(array.size() * 2);

		// Percolate up
		int hole = ++currentSize;
		for (; hole > 1 && x < array[hole / 2]; hole /= 2)
			array[hole] = array[hole / 2];
		array[hole] = x;
	}

	/**
	 * Remove the minimum item.
	 * Throws UnderflowException if empty.
	 */
	void deleteMin()
	{
		if (isEmpty())
			throw UnderflowException();

		array[1] = array[currentSize--];
		percolateDown(1);
	}

	/**
	 * Remove the minimum item and place it in minItem.
	 * Throws Underflow if empty.
	 */
	void deleteMin(Comparable & minItem)
	{
		if (isEmpty())
			throw UnderflowException();

		minItem = array[1];
		array[1] = array[currentSize--];
		percolateDown(1);
	}

	void makeEmpty()
	{
		currentSize = 0;
	}

private:
	int currentSize;  // Number of elements in heap
	vector<Comparable> array;        // The heap array

	/**
	 * Establish heap order property from an arbitrary
	 * arrangement of items. Runs in linear time.
	 */
	void buildHeap()
	{
		for (int i = currentSize / 2; i > 0; i--)
			percolateDown(i);
	}

	/**
	 * Internal method to percolate down in the heap.
	 * hole is the index at which the percolate begins.
	 */
	void percolateDown(int hole)
	{
		int child;
		Comparable tmp = array[hole];

		for (; hole * 2 <= currentSize; hole = child)
		{
			child = hole * 2;
			if (child != currentSize && array[child + 1] < array[child])
				child++;
			if (array[child] < tmp)
				array[hole] = array[child];
			else
				break;
		}
		array[hole] = tmp;
	}
};

struct event
{
	int arrival;
	int departure;
	int flightNum;
	int gateNum;
	string flight;
};

ofstream output;

template <typename Comparable>
class implementation
{
public:
	stack<int> gate;
	map<int, int> pair;

	void initializeGate()
	{
		int gateNum = 40;
		for (int i = 0; i < 31; i++)
		{
			gate.push(gateNum);
			gateNum--;
		}
	}
	void input(BinaryHeap<Comparable> & heap)
	{
		int flightNum = 1000;
		int hour = 0;

		for (int i = 0; i < 24; i++)
		{
			for (int j = 0; j < 60; j++)
			{
				if (j == 2)
				{
					event LAX;
					LAX.flightNum = flightNum++;
					LAX.flight = "LAX to JFK";
					LAX.arrival = 2 + hour;
					LAX.departure = LAX.arrival + probability();
					LAX.gateNum = checkGate(heap, LAX.arrival);
					heap.insert(LAX.departure);
					pair.insert({ LAX.departure, LAX.gateNum });
					if (LAX.gateNum != 0)
					{
						print(LAX);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 3)
				{
					event SMF;
					SMF.flightNum = flightNum++;
					SMF.flight = "SMF to RDU";
					SMF.arrival = 3 + hour;
					SMF.departure = SMF.arrival + probability();
					SMF.gateNum = checkGate(heap, SMF.arrival);
					heap.insert(SMF.departure);
					pair.insert({ SMF.departure, SMF.gateNum });
					if (SMF.gateNum != 0)
					{
						print(SMF);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 4)
				{
					event IAH;
					IAH.flightNum = flightNum++;
					IAH.flight = "IAH to MSP";
					IAH.arrival = 4 + hour;
					IAH.departure = IAH.arrival + probability();
					IAH.gateNum = checkGate(heap, IAH.arrival);
					heap.insert(IAH.departure);
					pair.insert({ IAH.departure, IAH.gateNum });
					if (IAH.gateNum != 0)
					{
						print(IAH);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 9)
				{
					event ABQ;
					ABQ.flightNum = flightNum++;
					ABQ.flight = "ABQ to ATL";
					ABQ.arrival = 9 + hour;
					ABQ.departure = ABQ.arrival + probability();
					ABQ.gateNum = checkGate(heap, ABQ.arrival);
					heap.insert(ABQ.departure);
					pair.insert({ ABQ.departure, ABQ.gateNum });
					if (ABQ.gateNum != 0)
					{
						print(ABQ);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 11)
				{
					event SJC;
					SJC.flightNum = flightNum++;
					SJC.flight = "SJC to BOS";
					SJC.arrival = 11 + hour;
					SJC.departure = SJC.arrival + probability();
					SJC.gateNum = checkGate(heap, SJC.arrival);
					heap.insert(SJC.departure);
					pair.insert({ SJC.departure, SJC.gateNum });
					if (SJC.gateNum != 0)
					{
						print(SJC);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 14)
				{
					event PHX;
					PHX.flightNum = flightNum++;
					PHX.flight = "PHX to MIA";
					PHX.arrival = 14 + hour;
					PHX.departure = PHX.arrival + probability();
					PHX.gateNum = checkGate(heap, PHX.arrival);
					heap.insert(PHX.departure);
					pair.insert({ PHX.departure, PHX.gateNum });
					if (PHX.gateNum != 0)
					{
						print(PHX);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 17)
				{
					event SFO;
					SFO.flightNum = flightNum++;
					SFO.flight = "SFO to ORD";
					SFO.arrival = 17 + hour;
					SFO.departure = SFO.arrival + probability();
					SFO.gateNum = checkGate(heap, SFO.arrival);
					heap.insert(SFO.departure);
					pair.insert({ SFO.departure, SFO.gateNum });
					if (SFO.gateNum != 0)
					{
						print(SFO);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 19)
				{
					event SLC;
					SLC.flightNum = flightNum++;
					SLC.flight = "SLC to AUS";
					SLC.arrival = 19 + hour;
					SLC.departure = SLC.arrival + probability();
					SLC.gateNum = checkGate(heap, SLC.arrival);
					heap.insert(SLC.departure);
					pair.insert({ SLC.departure, SLC.gateNum });
					if (SLC.gateNum != 0)
					{
						print(SLC);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 28)
				{
					event TUL;
					TUL.flightNum = flightNum++;
					TUL.flight = "TUL to ONT";
					TUL.arrival = 28 + hour;
					TUL.departure = TUL.arrival + probability();
					TUL.gateNum = checkGate(heap, TUL.arrival);
					heap.insert(TUL.departure);
					pair.insert({ TUL.departure, TUL.gateNum });
					if (TUL.gateNum != 0)
					{
						print(TUL);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 33)
				{
					event DCA;
					DCA.flightNum = flightNum++;
					DCA.flight = "DCA to LAS";
					DCA.arrival = 33 + hour;
					DCA.departure = DCA.arrival + probability();
					DCA.gateNum = checkGate(heap, DCA.arrival);
					heap.insert(DCA.departure);
					pair.insert({ DCA.departure, DCA.gateNum });
					if (DCA.gateNum != 0)
					{
						print(DCA);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 37)
				{
					event BNA;
					BNA.flightNum = flightNum++;
					BNA.flight = "BNA to SEA";
					BNA.arrival = 37 + hour;
					BNA.departure = BNA.arrival + probability();
					BNA.gateNum = checkGate(heap, BNA.arrival);
					heap.insert(BNA.departure);
					pair.insert({ BNA.departure, BNA.gateNum });
					if (BNA.gateNum != 0)
					{
						print(BNA);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 44)
				{
					event MAF;
					MAF.flightNum = flightNum++;
					MAF.flight = "MAF to AMA";
					MAF.arrival = 44 + hour;
					MAF.departure = MAF.arrival + probability();
					MAF.gateNum = checkGate(heap, MAF.arrival);
					heap.insert(MAF.departure);
					pair.insert({ MAF.departure, MAF.gateNum });
					if (MAF.gateNum != 0)
					{
						print(MAF);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 49)
				{
					event HOS;
					HOS.flightNum = flightNum++;
					HOS.flight = "HOS to DEN";
					HOS.arrival = 49 + hour;
					HOS.departure = HOS.arrival + probability();
					HOS.gateNum = checkGate(heap, HOS.arrival);
					heap.insert(HOS.departure);
					pair.insert({ HOS.departure, HOS.gateNum });
					if (HOS.gateNum != 0)
					{
						print(HOS);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else if (j == 55)
				{
					event ELP;
					ELP.flightNum = flightNum++;
					ELP.flight = "ELP to MEM";
					ELP.arrival = 55 + hour;
					ELP.departure = ELP.arrival + probability();
					ELP.gateNum = checkGate(heap, ELP.arrival);
					heap.insert(ELP.departure);
					pair.insert({ ELP.departure, ELP.gateNum });
					if (ELP.gateNum != 0)
					{
						print(ELP);
					}
					else
					{
						output << "Airport full" << endl;
					}
				}
				else
				{
				continue;
				}
			}
			hour = hour + 60;
		}
	}
private:
	int probability()
	{
		if ((rand() % 100) < 40)
		{
			int delayTime = rand() % 20;
			return 80 + delayTime;
		}
		else
		{
			return 60;
		}
	}
	int checkGate(BinaryHeap<Comparable> & heap, int arrival)
	{
		int tempDepart = 0;
		int tempGate = 0;

		if (!gate.empty())
		{
			tempGate = gate.top();
			gate.pop();
			return tempGate;
		}
		else
		{
			tempDepart = heap.findMin();
			if (tempDepart > arrival)
			{
				return 0;
			}
			else
			{
				tempGate = pair.find(tempDepart)->second;
				heap.deleteMin();
				return tempGate;
			}

		}
	}
	void print(event flight)
	{
		string tempA;
		string tempD;
		int hourA = flight.arrival / 60;
		int minuteA = flight.arrival % 60;

		if (hourA < 10)
		{
			tempA = "0" + to_string(hourA) + ":";
			if (minuteA < 10)
			{
				tempA = tempA + "0" + to_string(minuteA);
			}
			else
			{
				tempA = tempA + to_string(minuteA);
			}
		}
		else
		{
			tempA = to_string(hourA) + ":";
			if (minuteA < 10)
			{
				tempA = tempA + "0" + to_string(minuteA);
			}
			else
			{
				tempA = tempA + to_string(minuteA);
			}
		}

		int hourD = flight.departure / 60;
		int minuteD = flight.departure % 60;

		if (hourD < 10)
		{
			tempD = "0" + to_string(hourD) + ":";
			if (minuteD < 10)
			{
				tempD = tempD + "0" + to_string(minuteD);
			}
			else
			{
				tempD = tempD + to_string(minuteD);
			}
		}
		else if (hourD < 24)
		{
			tempD = to_string(hourD) + ":";
			if (minuteD < 10)
			{
				tempD = tempD + "0" + to_string(minuteD);
			}
			else
			{
				tempD = tempD + to_string(minuteD);
			}
		}
		else
		{
			tempD = "Tomorrow";
		}

		output << "Flight number: " << flight.flightNum << "\t" << flight.flight << endl;
		output << "Arrival time: " << tempA << "\t" << "Departure time: " << tempD << "\t" << "Gate number: " << flight.gateNum << endl;
		output << endl;
	}
};

int main()
{
	BinaryHeap<int> heap;
	implementation<int> assign9;
	srand((unsigned int)time(NULL));

	assign9.initializeGate();
	output.open("output.txt");
	assign9.input(heap);
}

